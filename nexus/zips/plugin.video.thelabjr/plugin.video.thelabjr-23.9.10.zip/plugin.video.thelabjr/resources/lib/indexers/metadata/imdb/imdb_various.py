# -*- coding: utf-8 -*-
#___________.__           .____          ___.         ____.       
#\__    ___/|  |__   ____ |    |   _____ \_ |__      |    |______ 
#  |    |   |  |  \_/ __ \|    |   \__  \ | __ \     |    \_  __ \
#  |    |   |   Y  \  ___/|    |___ / __ \| \_\ \/\__|    ||  | \/
#  |____|   |___|  /\___  >_______ (____  /___  /\________||__|   
#                \/     \/        \/    \/    \/                  
#Credit to JewBMX for base code

genre_list = [
    ('Action', 'action', True),
    ('Adventure', 'adventure', True),
    ('Animation', 'animation', True),
    ('Anime', 'anime', False),
    ('Biography', 'biography', True),
    ('Comedy', 'comedy', True),
    ('Crime', 'crime', True),
    ('Documentary', 'documentary', True),
    ('Drama', 'drama', True),
    ('Family', 'family', True),
    ('Fantasy', 'fantasy', True),
    ('Game-Show', 'game_show', True),
    ('History', 'history', True),
    ('Horror', 'horror', True),
    ('Music ', 'music', True),
    ('Musical', 'musical', True),
    ('Mystery', 'mystery', True),
    ('News', 'news', True),
    ('Reality-TV', 'reality_tv', True),
    ('Romance', 'romance', True),
    ('Science Fiction', 'sci_fi', True),
    ('Sport', 'sport', True),
    ('Superhero', 'superhero', False),
    ('Talk-Show', 'talk_show', True),
    ('Thriller', 'thriller', True),
    ('War', 'war', True),
    ('Western', 'western', True)
]


keywords_list = [
    ('2d-animation'), ('action-hero'), ('alternate-history'), ('ambiguous-ending'), ('americana'), ('anime'), ('anti-hero'), ('avant-garde'),
    ('b-movie'), ('b-western'), ('bank-heist'), ('based-on-book'), ('based-on-comic'), ('based-on-comic-book'), ('based-on-novel'),
    ('based-on-novella'), ('based-on-play'), ('based-on-short-story'), ('based-on-true-story'), ('battle'), ('betrayal'), ('biker'),
    ('black-comedy'), ('blockbuster'), ('bollywood'), ('breaking-the-fourth-wall'), ('business'), ('caper'), ('car-accident'),
    ('car-chase'), ('car-crash'), ('character-name-in-title'), ('characters-point-of-view-camera-shot'), ('chick-flick'), ('christmas'),
    ('coming-of-age'), ('competition'), ('conspiracy'), ('cop'), ('corruption'), ('criminal-mastermind'), ('cult'), ('cult-film'),
    ('cyberpunk'), ('dark-hero'), ('dc-comics'), ('deus-ex-machina'), ('dialogue-driven'), ('dialogue-driven-storyline'), ('directed-by-star'),
    ('director-cameo'), ('disney'), ('documentary-subject'), ('double-cross'), ('dream-sequence'), ('drugs'), ('dystopia'), ('easter'),
    ('ensemble-cast'), ('epic'), ('espionage'), ('existential'), ('experimental'), ('experimental-film'), ('fairy-tale'), ('famous-line'),
    ('famous-opening-theme'), ('famous-score'), ('fantasy-sequence'), ('farce'), ('father-daughter-relationship'), ('father-son-relationship'),
    ('femme-fatale'), ('fictional-biography'), ('flashback'), ('french-new-wave'), ('futuristic'), ('gangster'), ('good-versus-evil'),
    ('halloween'), ('hearing-characters-thoughts'), ('heist'), ('hero'), ('high-school'), ('horror-movie-remake'), ('husband-wife-relationship'),
    ('idealism'), ('independent-film'), ('investigation'), ('kidnapping'), ('knight'), ('kung-fu'), ('loner'), ('macguffin'), ('marvel-comics'),
    ('may-december-romance'), ('medieval-times'), ('mockumentary'), ('monster'), ('mother-daughter-relationship'), ('mother-son-relationship'),
    ('multiple-actors-playing-same-role'), ('multiple-endings'), ('multiple-perspectives'), ('multiple-storyline'), ('multiple-time-frames'),
    ('murder'), ('musical-number'), ('neo-noir'), ('neorealism'), ('new-year'), ('ninja'), ('no-background-score'), ('no-music'),
    ('no-opening-credits'), ('no-title-at-beginning'), ('nonlinear-timeline'), ('official-james-bond-series'), ('on-the-run'), ('one-against-many'),
    ('one-man-army'), ('opening-action-scene'), ('organized-crime'), ('parenthood'), ('parody'), ('plot-twist'), ('police-corruption'),
    ('police-detective'), ('post-apocalypse'), ('postmodern'), ('private-eye'), ('psychopath'), ('race-against-time'), ('racism'), ('redemption'),
    ('remake'), ('rescue'), ('road-movie'), ('robbery'), ('robot'), ('rotoscoping'), ('satire'), ('schizophrenia'), ('self-sacrifice'),
    ('serial-killer'), ('shakespeare'), ('shootout'), ('show-within-a-show'), ('slasher'), ('southern-gothic'), ('spaghetti-western'),
    ('spirituality'), ('spoof'), ('star-trek'), ('star-wars'), ('steampunk'), ('subjective-camera'), ('superhero'), ('supernatural'),
    ('surprise-ending'), ('survival-horror'), ('swashbuckler'), ('sword-and-sandal'), ('tech-noir'), ('thanksgiving'), ('time-travel'),
    ('title-spoken-by-character'), ('told-in-flashback'), ('vampire'), ('virtual-reality'), ('voice-over-narration'), ('war-violence'),
    ('whistleblower'), ('wilhelm-scream'), ('wuxia'), ('zombie')
]


languages_list = [
    ('Arabic', 'ar'),
    ('Bosnian', 'bs'),
    ('Bulgarian', 'bg'),
    ('Chinese', 'zh'),
    ('Croatian', 'hr'),
    ('Dutch', 'nl'),
    ('English', 'en'),
    ('Finnish', 'fi'),
    ('French', 'fr'),
    ('German', 'de'),
    ('Greek', 'el'),
    ('Hebrew', 'he'),
    ('Hindi ', 'hi'),
    ('Hungarian', 'hu'),
    ('Icelandic', 'is'),
    ('Italian', 'it'),
    ('Japanese', 'ja'),
    ('Korean', 'ko'),
    ('Macedonian', 'mk'),
    ('Norwegian', 'no'),
    ('Persian', 'fa'),
    ('Polish', 'pl'),
    ('Portuguese', 'pt'),
    ('Punjabi', 'pa'),
    ('Romanian', 'ro'),
    ('Russian', 'ru'),
    ('Serbian', 'sr'),
    ('Slovenian', 'sl'),
    ('Spanish', 'es'),
    ('Swedish', 'sv'),
    ('Turkish', 'tr'),
    ('Ukrainian', 'uk')
]


