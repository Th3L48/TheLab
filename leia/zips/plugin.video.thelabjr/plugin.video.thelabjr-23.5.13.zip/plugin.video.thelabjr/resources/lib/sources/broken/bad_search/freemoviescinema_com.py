# -*- coding: utf-8 -*-
#___________.__           .____          ___.         ____.       
#\__    ___/|  |__   ____ |    |   _____ \_ |__      |    |______ 
#  |    |   |  |  \_/ __ \|    |   \__  \ | __ \     |    \_  __ \
#  |    |   |   Y  \  ___/|    |___ / __ \| \_\ \/\__|    ||  | \/
#  |____|   |___|  /\___  >_______ (____  /___  /\________||__|   
#                \/     \/        \/    \/    \/                  
#Credit to JewBMX for base code

import re

from six.moves.urllib_parse import parse_qs, urlencode

from resources.lib.modules import client
from resources.lib.modules import client_utils
from resources.lib.modules import cleantitle
from resources.lib.modules import scrape_sources



class source:
    def __init__(self):
        self.results = []
        self.domains = ['freemoviescinema.com']
        self.base_link = 'https://www.freemoviescinema.com'
        self.search_link = 'https://www.startpage.com/do/search?q=%s+%s+site:freemoviescinema.com'


    def movie(self, imdb, title, localtitle, aliases, year):
        url = {'imdb': imdb, 'title': title, 'year': year}
        url = urlencode(url)
        return url


    def sources(self, url, hostDict):
        try:
            if url == None:
                return self.results
            data = parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
            title = data['title']
            year = data['year']
            search_title = cleantitle.get_plus(title)
            check_title = '%s+(%s)' % (search_title, year)
            search_url = self.search_link % (search_title, year)
            html = client.request(search_url, headers=client.dnt_headers)
            r = client_utils.parseDOM(html, 'div', attrs={'class': 'w-gl__result-second-line-container'})
            r = zip(client_utils.parseDOM(r, 'a', ret='href'), client_utils.parseDOM(r, 'h3'))
            results = [(i[0], i[1]) for i in r if len(i[0]) > 0 and len(i[1]) > 0]
            result_url = [i[0] for i in results if check_title in cleantitle.get_plus(i[1])][0]
            result_html = client.request(result_url)
            links = client_utils.parseDOM(result_html, 'iframe', ret='src')
            for link in links:
                for source in scrape_sources.process(hostDict, link):
                    self.results.append(source)
            return self.results
        except:
            #log_utils.log('sources', 1)
            return self.results


    def resolve(self, url):
        return url


