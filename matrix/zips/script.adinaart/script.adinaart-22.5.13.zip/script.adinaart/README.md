# script.adinaart

